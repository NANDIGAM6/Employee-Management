using EmployeesManagement.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
// support for MVC (Model-View-Controller) to the application. It configures the service container to use controllers and views, which is essential for handling web requests and returning HTML views.
builder.Services.AddControllersWithViews();
//This line configures Entity Framework Core to use a SQL Server database. It adds the ApplicationDbContext as a service in the dependency injection container
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
//This configures ASP.NET Core Identity, which is a membership system that adds login functionality to your application. It uses IdentityUser and IdentityRole as the types for users and roles
builder.Services.AddIdentity<IdentityUser, IdentityRole>()
       .AddEntityFrameworkStores<ApplicationDbContext>()
       .AddDefaultTokenProviders();

//This line adds session state services to the application
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

//This  builds the application pipeline, initializing the configured services and middleware
var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

//This adds middleware to redirect HTTP requests to HTTPS, ensuring secure communication.
app.UseHttpsRedirection();
//This  enables the serving of static files (like CSS, JavaScript, images) from the wwwroot folder.
app.UseStaticFiles();
//This  adds routing middleware to the request pipeline, enabling the app to route requests to the appropriate controllers and actions.
app.UseRouting();
//This  adds authorization middleware to the request pipeline, which ensures that only authorized users can access certain parts of the application.
app.UseAuthorization();
//This  adds authentication middleware to the request pipeline, allowing the application to handle authentication requests and manage user identity.
app.UseAuthentication();
//This  adds session middleware to the request pipeline, allowing the application to manage session state.
app.UseSession();
//This  configures the default route for the application, specifying that if no controller or action is specified in the URL, the application should use the Home controller and its Index action. The {id?} part makes the id parameter optional.
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");
//This line runs the application, starting the request processing pipeline.
app.Run();