﻿using System.ComponentModel.DataAnnotations;

namespace EmployeesManagement.Models
{
    public class Department
    {
        public int ID { get; set; }
        [Required(ErrorMessage = "The Name field is required.")]
        [StringLength(100, MinimumLength = 2, ErrorMessage = "The Name must be between 2 and 100 characters.")]
        public string Name { get; set; }
        public ICollection<Employee> Employees { get; set; }
    }
}
