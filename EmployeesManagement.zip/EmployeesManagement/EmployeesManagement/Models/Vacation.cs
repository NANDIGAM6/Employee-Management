﻿namespace EmployeesManagement.Models
{
    public class Vacation
    {
        public int ID { get; set; }
        public int EmployeeID { get; set; }
        public Employee Employee { get; set; }
        public int NumberOfDays { get; set; }
    }
}